import io
import socket
import re
import http.server
import urllib.parse
import http.server
import socketserver
import logging
import cgi
import threading
import sys
import ssl
from urllib.parse import unquote

class ServerHandler(http.server.SimpleHTTPRequestHandler):

    def do_GET(self):
        logging.error(self.headers)
        http.server.SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        if self.path == '/config':
            # Expect the request to be a form submission containing a textarea named 'words'
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD':'POST',
                        'CONTENT_TYPE':self.headers['Content-Type'],
                        })

            # Get the words from the textarea
            words = form.getvalue('words')

            # Split the words by newline to get a list
            words_list = words.split('\n')

            # Write the words to the configuration file
            with open('blockRules.txt', 'w') as file:
                for word in words_list:
                    file.write(word + '\n')
                    
        else:
            # Handle other POST requests as before...
            logging.error(self.headers)
            form = cgi.FieldStorage(
                fp=self.rfile,
                headers=self.headers,
                environ={'REQUEST_METHOD':'POST',
                        'CONTENT_TYPE':self.headers['Content-Type'],
                        })
            for item in form.list:
                logging.error(item)
            http.server.SimpleHTTPRequestHandler.do_GET(self)
class ProxyHandler:
    def __init__(self, port, forbiddenRulesFile, blockRulesFile) -> None:
        #   Config argument
        self._port = port
        self._forbiddenRules = self.loadListRules(forbiddenRulesFile)
        self._blocked_words = self.loadListRules(blockRulesFile)

        #   Create TCP server
       
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP)
        self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) 
        self._socket.bind(('', self._port))
        self._socket.listen(socket.SOMAXCONN)
        self._proxy_value = "on"

        t = threading.Thread(target = self.create_TCPserver)
        t.start()


    def TSAP(self, request):
        #   Check method 
        check_GET = re.compile(r'GET ([^:]+)://([a-zA-Z0-9\.\-\_]+)/([^\s]*)').search(request)
        check_CONNECT = re.compile(r'CONNECT ([a-zA-Z0-9\.\-\_]+):([0-9]+)([^\s]*)').search(request)
        check_POST = re.compile(r'POST ([^:]+)://([a-zA-Z0-9\.\-\_]+)/([^\s]*)').search(request)
        if check_GET:
            server_name = check_GET.group(2)
            server_path = check_GET.group(3)
            IP = socket.gethostbyname(str(server_name))
            return((IP,80, server_name, server_path))
        elif check_CONNECT:
            server_name = check_CONNECT.group(1)
            #server_path = check_CONNECT.group(2)
            server_path = ""
            IP = socket.gethostbyname(str(server_name))
            return((IP, 443, server_name, server_path))
        elif check_POST:
            server_name = check_POST.group(2)
            server_path = check_POST.group(3)
            IP = socket.gethostbyname(str(server_name))
            return((IP,80, server_name, server_path))
        return ("", "", "", "")

    def headerOK(self):
        return b'''HTTP/1.1 200 OK\r\n\r\n'''
    def headerNotFound(self): 
        return b'''HTTP/1.1 404 Not Found\r\n\r\n'''
    def headerForbidden(self): 
        return "HTTP/1.1 403 Forbidden\r\n\r\n<html><body><h1>Access Denied</h1> <h3>You requested a forbidden resource or forbidden content</h3></body></html>"

    def loadListRules(self, file):
        with open(file, "rb") as f:
            return list(map(lambda x:x.lower(), f.read().strip().splitlines()))
        
    def recvall(self, _socket, timeout = 1):
        # recv all data
        data = b""
        _socket.settimeout(timeout) # because browser not end TCP so we need to set timeout for _socket.recv
        try:
            while 1:
                buffer = _socket.recv(1024) # receive buffer
                if (not buffer):
                    break
                data += buffer # add buffer to data
        except: # case timeout
            pass
        return data

    def block_request(self, server_path):
        for s in self._forbiddenRules:
            if s.decode("utf-8") in server_path:
                return True
        return False

    def filter_request(self, request):
        request = request.replace('HTTP/1.1', 'HTTP/1.0')
        request = request.replace('Connection: keep-alive', 'Connection: Close')
        return request
    def filter_content(self, data):
        try:
            headers, body = data.split(b'\r\n\r\n', 1)
            # Parse headers
            headers_dict = http.client.parse_headers(io.BytesIO(headers))

            # Check content type
            content_type = headers_dict.get('Content-Type')
            if content_type is not None and 'HTML' in content_type:
                # Decode body
                body = body.decode('utf-8')

                # Apply filters to body
                for blocked_word in self._blocked_words:
                    body = body.replace(str(blocked_word), '[BLOCKED]')

                # Modify HTML title
                body = re.sub('<title>.*?</title>', '<title>Filtered Content by Huy-Proxy</title>', body)

                # Delete all mp4 resources
                body = re.sub(r'<source.*?type="video/mp4".*?>', '', body)

                # Re-encode body
                body = body.encode('utf-8')

                # Reassemble response
                data = b'\r\n\r\n'.join([headers, body])
            else:
                content = data.decode("utf8")
                content = re.sub('<title>.*?</title>', '<title>Filtered Content by Huy-Proxy</title>', content)
                content = content.encode('utf-8')
                data = content

        except Exception:
            pass  # Error occurred, return original data
        return data
    def forward_data(self, source_socket, target_socket):
        while True:
            data = source_socket.recv(4096)
            if len(data) == 0:
                break
            target_socket.sendall(data)

    def start(self):
        print("Proxy is running on port 1511")
        while True:
            (clientSocket, clientAddress) = self._socket.accept() # accept connect
            t = threading.Thread(target = self.request_handle, args=(clientSocket, clientAddress))
            t.setDaemon(True)
            t.start()
    

    #   Handling request
    def request_handle(self, clientSocket, clientAddress):
        request = clientSocket.recv(4096)
        #print(clientAddress, clientSocket)
        #print(request)
        if not request: 
            return clientSocket.close()
        
        #   check /config request

        if 'GET /config' in request.decode():
            response = self.config_page()
            clientSocket.sendall(response)
            return clientSocket.close()
        if 'POST /config' in request.decode():
            #print(request)
            # Parse POST data
            post_data = request.decode().split("\r\n\r\n", 1)[1]

            # Extract value after 'words='
            post_dict = dict(re.findall(r'(\w+)=(\w+|%0D%0A\w+)', post_data))

            # URL-decode and split words into list
            words_list = unquote(post_dict['words']).split('\r\n')

            # Get value of 'proxy'
            self._proxy_value = post_dict['proxy']


            with open('blockRules.txt', 'w') as file:
                for word in words_list:
                    file.write(word + '\n')
            response = self.config_page()
            clientSocket.sendall(response)
            return clientSocket.close()
        request=request.decode("utf8")
        #print("Request........: ")
        #print(request)

        
        

        target_IP, target_PORT, target_server_name, target_server_path = self.TSAP(request)
        if not target_IP or not target_PORT:
            return clientSocket.close()
        #print(target_IP, target_PORT, target_server_name)

        #   Check whether header has forbidden cotent
        if target_server_path and self.block_request(target_server_path):
            clientSocket.sendall(self.headerForbidden().encode("utf8"))
            return clientSocket.close()

        if target_PORT == 443:  # This is a HTTPS request
            try:
                # Connect to the target server
                server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                server_socket.connect((target_IP, target_PORT))

                # Send a successful HTTP response to the client
                clientSocket.sendall(b"HTTP/1.1 200 Connection established\r\n\r\n")

                # Start forwarding data between client and server
                self.forward_data(clientSocket, server_socket)
            except Exception as e:
                print(e)
            finally:
                server_socket.close()
                return clientSocket.close()
            
        #   Filter Request
        request = self.filter_request(request)
        print(request)

        
        #   Create SSL if HTTPS
        try:
            # Create a socket to connect to the server
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM,socket.IPPROTO_TCP)
            server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            server_socket.connect((target_IP, target_PORT))
            # Wrap the socket with SSL to establish a secure connection
            if target_PORT == 443:
                context = ssl.create_default_context()
                server_socket = context.wrap_socket(server_socket, server_hostname=target_server_name)
        except Exception as e:
            print("can not connect to " + target_IP)
            print(e.args)
            clientSocket.close()
        #print("sucesss!")

        request = request.encode("utf8")
        #server_socket.sendall(self.headerOK())
        server_socket.sendall(request)

        while True:
            #data_recv = server_socket.recv(4096)
            data_recv = self.recvall(server_socket)
            if self._proxy_value == "on":
                data_recv = self.filter_content(data_recv)
            if data_recv:
                # if target_PORT == 443:
                #     print("Received data: ")
                #     print(data_recv)
                clientSocket.sendall(data_recv)
            else:
                break
        server_socket.close()
        return clientSocket.close()

    def config_page(self):
        with open('config.html', 'rb') as f:
            content = f.read()

        response = [
            b'HTTP/1.1 200 OK',
            b'Content-Type: text/html',
            b'Content-Length: %d' % len(content),
            b'Connection: close',
            b'',
            content
        ]
        return b'\r\n'.join(response)




    def create_TCPserver(self):
        while True:
            self._httpd = socketserver.TCPServer(("", 2007), ServerHandler)
            #print("TCPServer is running at Port 2007")
            self._httpd.serve_forever()

def main():
    proxyHandler = ProxyHandler(port = 1511, forbiddenRulesFile = "forbiddenRules.txt", blockRulesFile = "blockRules.txt")
    proxyHandler.start()
    return 0

if __name__ == '__main__':
    sys.exit(main())